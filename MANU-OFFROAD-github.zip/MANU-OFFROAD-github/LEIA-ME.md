# MANU OFF-ROAD — by MANU GAMES

Esta pasta já está pronta para o GitHub. Ela faz **duas coisas sozinha**:

1. **Gera o APK** (app Android) — workflow `Gerar APK`
2. **Publica o jogo como site/app instalável** — workflow `Publicar site`

## Passo a passo

1. No GitHub, crie um repositório novo (ex.: `manu-offroad`).
2. Envie **todos** os arquivos desta pasta para o repositório
   (inclusive a pasta `.github`, que tem os dois workflows).
3. Aba **Actions** → rode **Gerar APK** (botão *Run workflow*).
   Quando terminar (uns 5–10 min), abra a execução e baixe
   **MANU-OFFROAD-apk** em *Artifacts*. Dentro do zip está o `app-debug.apk`.
4. Para o site: **Settings → Pages → Source: GitHub Actions**, depois rode
   **Publicar site**. O link fica em `https://SEU-USUARIO.github.io/manu-offroad/`.
   Abra esse link no Chrome do Android e toque em **INSTALAR APP**.

## Observações

- O APK é "debug": instala normalmente, mas o Android pede para permitir
  instalar de fontes desconhecidas.
- Se a pasta `.github` não subir pelo celular, crie os dois arquivos em
  *Add file → Create new file*, digitando o nome `.github/workflows/apk.yml`
  (e `pages.yml`) e colando o conteúdo.
- O jogo fica na pasta `www/`. Para atualizar, é só trocar o `index.html` ali.
